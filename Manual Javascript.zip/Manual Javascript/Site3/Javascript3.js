function inicio() {
    let nome = window.prompt('Qual é o seu nome? ')
    window.alert(`Olá, ${nome}! É um prazer te conhecer!`)
}