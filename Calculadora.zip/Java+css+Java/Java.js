function somar() {
    let n1 = Number(window.prompt('Digite um numero'))
    let n2 = Number(window.prompt('Digite outro numero'))
    soma = n1 + n2

    let res = document.querySelector('section#res')
    res.innerHTML = `<p> a soma entre ${n1} e ${n2} é igual a ${soma} </p>`

}